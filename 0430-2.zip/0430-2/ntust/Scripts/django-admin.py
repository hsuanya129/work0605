#!c:\users\claire\desktop\0430-2\ntust\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
